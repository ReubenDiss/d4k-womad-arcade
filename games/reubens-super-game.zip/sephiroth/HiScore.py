class HiScore:
  HiScore :int = 0