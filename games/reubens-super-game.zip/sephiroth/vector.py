class vector :
  vy = 1
  vx = 0